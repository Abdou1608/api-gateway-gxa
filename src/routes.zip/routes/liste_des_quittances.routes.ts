import { Router } from 'express';
import { quittance_listitems } from '../services/liste_des_quittances/quittance_listitems.service';
import { BasSecurityContext } from '../Model/BasSoapObject/BasSecurityContext';

const router = Router();

router.post('/', async (req, res) => {
  try {
    const _BasSecurityContext= new BasSecurityContext()
  _BasSecurityContext.IsAuthenticated=true
  _BasSecurityContext.SessionId=req.body.BasSecurityContext?._SessionId
 const dossier =req.body.dossier
 const contrat=req.body.contrat 

    const result = await quittance_listitems(dossier,contrat,_BasSecurityContext);
    res.json(result);
  } catch (error:any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;