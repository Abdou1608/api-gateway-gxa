import { Router } from 'express';
import { cont_details } from '../services/detail_contrat/cont_details.service';
import { BasSecurityContext } from '../Model/BasSoapObject/BasSecurityContext';

const router = Router();

router.post('/', async (req, res) => {
  try {
    const _BasSecurityContext= new BasSecurityContext()
    _BasSecurityContext.IsAuthenticated=true
    _BasSecurityContext.SessionId=req.body.BasSecurityContext?._SessionId
    const result = await cont_details(req.body,_BasSecurityContext);
    res.json(result);
  } catch (error:any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;