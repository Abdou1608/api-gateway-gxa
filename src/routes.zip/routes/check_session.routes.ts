import { Router } from 'express';
import { checksession_ } from '../services/check_session/checksession_.service';
import { BasSecurityContext } from '../Model/BasSoapObject/BasSecurityContext';

const router = Router();

router.post('/', async (req, res) => {
  try {
    const _BasSecurityContext= new BasSecurityContext()
    _BasSecurityContext.IsAuthenticated=true
    _BasSecurityContext.SessionId=req.body.BasSecurityContext?._SessionId
    const result = await checksession_(_BasSecurityContext);
    res.json(result);
  } catch (error:any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;