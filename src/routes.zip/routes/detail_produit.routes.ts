import { Router } from 'express';
import { produit_details } from '../services/detail_produit/produit_details.service';
import { BasSecurityContext } from '../Model/BasSoapObject/BasSecurityContext';

const router = Router();

router.post('/', async (req, res) => {
  try {
    const _BasSecurityContext= new BasSecurityContext()
    _BasSecurityContext.IsAuthenticated=true
    _BasSecurityContext.SessionId=req.body.BasSecurityContext?._SessionId
    const code=req.body.code
    const options=req.body.options ?? false
    const basecouvs= req.body.basecouvs ?? false
    const clauses= req.body.clauses?? false
    const result = await produit_details(code,_BasSecurityContext, options,basecouvs,clauses);
    res.json(result);
  } catch (error:any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;