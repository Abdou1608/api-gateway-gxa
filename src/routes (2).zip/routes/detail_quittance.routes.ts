import { Router } from 'express';
import { quittance_details } from '../services/detail_quittance/quittance_details.service';
import { BasSecurityContext } from '../Model/BasSoapObject/BasSecurityContext';

const router = Router();

router.post('/', async (req, res) => {
  try {
    const _BasSecurityContext= new BasSecurityContext()
    _BasSecurityContext.IsAuthenticated=true
    _BasSecurityContext.SessionId=req.body.BasSecurityContext?._SessionId
    const quittance=req.body.quittance
    const details=req.body.details ?? true
    const basecouvs= req.body.basecouvs ?? false
    const result = await quittance_details(quittance,details,_BasSecurityContext);
    res.json(result);
  } catch (error:any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;