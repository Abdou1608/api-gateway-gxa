// src/app/models/user.model.ts
export interface User {
    dossier?: number;
    login: string;
    role?: number;
    Rsociale?: string;
    portef?: string;
    email?: string;
    ordreext?: number;
  }
  