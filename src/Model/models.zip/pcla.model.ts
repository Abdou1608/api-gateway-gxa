export interface Pcla {
    /** Numéro contrat */
    contrat: number;
  
    /** numéro piece */
    piece: number;
  
    /** code produit */
    codeprod: string;
  
    /** clauses */
    clause: string;
  
    /** N° ordre */
    ordre?: number;
  }